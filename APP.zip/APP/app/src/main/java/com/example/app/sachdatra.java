package com.example.app;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link sachdatra#newInstance} factory method to
 * create an instance of this fragment.
 */
public class sachdatra extends Fragment {
    Context context;
    private View v;
    ListView lib;
    DBHelper db;
    ArrayList<String> tensach;
    ArrayList<String> ngaymuon;
    ArrayList<String> ngayhentra;
    private Library library;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public sachdatra() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment sachdatra.
     */
    // TODO: Rename and change types and number of parameters
    public static sachdatra newInstance(String param1, String param2) {
        sachdatra fragment = new sachdatra();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        library = (Library) getActivity();
        v =  inflater.inflate(R.layout.fragment_sachdatra, container, false);
        db = new DBHelper(getContext());
        String userID = library.setID();
        tensach = db.setSachdatra(userID);
        ngaymuon = db.setngaymuon2(userID);
        ngayhentra = db.setngaytra2(userID);

        lib = v.findViewById(R.id.lv_lib1);
        ProgramAdater programAdater = new ProgramAdater(getContext(), tensach, ngaymuon, ngayhentra);
        lib.setAdapter(programAdater);
        return v;
    }
}