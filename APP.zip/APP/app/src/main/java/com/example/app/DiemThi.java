package com.example.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;

public class DiemThi extends AppCompatActivity {
    ListView diemthi;
    DBHelper db;
    ArrayList<String> tenmon;
    ArrayList<String> dqt;
    ArrayList<String> thi;
    ArrayList<String> Diemchu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diem_thi);
        db = new DBHelper(this);
        String userID = getIntent().getStringExtra("name_id");
        tenmon = db.setMonhoc(userID);
        dqt = db.setDQT(userID);
        thi = db.setDT(userID);
        Diemchu = db.setdiemchu(userID);

        diemthi = findViewById(R.id.diemthi);
        AnhXaDiem programAdater = new AnhXaDiem(this, tenmon,  dqt, thi, Diemchu);
        diemthi.setAdapter(programAdater);
    }
    public void diem_back(View view) {
        Intent intent = new Intent(DiemThi.this, LoginActivity.class);
        startActivity(intent);
    }
}