package com.example.app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity  {
    DBHelper db;
    Button bt_login;
    private EditText id, pw;
    private String mid="";
    public Session sessionManagement;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        db = new DBHelper(this);
        bt_login =(Button)findViewById(R.id.bt_login);
        id =(EditText)findViewById(R.id.id1);
        pw =(EditText)findViewById(R.id.password);
        }
    @Override
    protected void onStart() {
        super.onStart();

        checkSession();
    }

    private void checkSession() {
        //check if user is logged in
        //if user is logged in --> move to mainActivity

         sessionManagement = new Session(LoginActivity.this);
        String userID = sessionManagement.getSession1();
        String userPass = sessionManagement.getSession();
        if(!userID.equals("1")){
            moveToLogin();
        }
        else{
            //do nothing
        }
    }

    public void login(View view) {
        String s1 = id.getText().toString().trim();
        String s2 = pw.getText().toString();
        // 1.log in to app and save session of user
        // 2. move to mainActivity

        //1. login and save session
        User user = new User(s1,s2);
        sessionManagement = new Session(LoginActivity.this);
        sessionManagement.saveSession1(user);

        //2. step
        moveToMainActivity();
    }
    private void moveToLogin() {
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        intent.putExtra("name_id", sessionManagement.getSession1());
        sessionManagement = new Session(LoginActivity.this);
        String userID = sessionManagement.getSession1();
        String exname = db.loadData(userID);
        intent.putExtra("name", exname);
        String class_a = db.setClass(userID);
        intent.putExtra("class", class_a);
        String khoa = db.setKhoa(userID);
        intent.putExtra("khoa", khoa);
        String k = db.setK(userID);
        intent.putExtra("K", k);
        String nam = db.setNam(userID);
        intent.putExtra("namhoc", nam);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    private void moveToMainActivity() {
        Log.i("lk", sessionManagement.getSession1());
            String s1 = id.getText().toString().trim();
            String s2 = pw.getText().toString();
            Boolean check = db.check_idpw(s1, s2);
            if (check == true) {
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                intent.putExtra("name_id", sessionManagement.getSession1());
                String exname = db.loadData(s1);
                intent.putExtra("name", exname);
                String class_a = db.setClass(s1);
                intent.putExtra("class", class_a);
                String khoa = db.setKhoa(s1);
                intent.putExtra("khoa", khoa);
                String k = db.setK(s1);
                intent.putExtra("K", k);
                String nam = db.setNam(s1);
                intent.putExtra("namhoc", nam);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            } else {
                Toast.makeText(getApplicationContext(), "Thất bại", Toast.LENGTH_SHORT).show();
                Toast.makeText(getApplicationContext(), sessionManagement.getSession1(), Toast.LENGTH_SHORT).show();
            }
        }
    //}

}





