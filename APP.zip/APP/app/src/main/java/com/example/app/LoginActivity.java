package com.example.app;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.Timer;
import java.util.TimerTask;

public class LoginActivity extends AppCompatActivity  {
    DBHelper db;
    Button bt_login;
    private EditText id, pw;
    private String mid="";
    public Session sessionManagement;
    BroadCastWifi br;
    private BroadCastWifi broadCastWifi;
    ProgressBar progressBar;
    int count = 0;
    Timer timer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        db = new DBHelper(this);
        br = new BroadCastWifi();
        bt_login =(Button)findViewById(R.id.bt_login);
        id =(EditText)findViewById(R.id.id1);
        pw =(EditText)findViewById(R.id.password);
        broadCastWifi = new BroadCastWifi();
        progressBar = findViewById(R.id.progressBar);
        timer = new Timer();
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                count++;
                progressBar.setProgress(count);
                if(count == 10){
                    timer.cancel();
                }
            }
        };
        timer.schedule(timerTask,0,10);
        }
    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter intentFilter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(broadCastWifi, intentFilter);
        //check xem đã đăng xuất chưa
        checkSession();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadCastWifi);
    }

    private void checkSession() {
        sessionManagement = new Session(LoginActivity.this);
        String userID = sessionManagement.getSession1();
        if(!userID.equals("1")){
            moveToMainActivity();
        }
        else{
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void login(View view) {
        String s1 = id.getText().toString().trim();
        String s2 = pw.getText().toString();

        User user = new User(s1,s2);
        sessionManagement = new Session(LoginActivity.this);
        sessionManagement.saveSession1(user);
        moveToLogin();
    }
    private void moveToMainActivity() {
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        intent.putExtra("name_id", sessionManagement.getSession1());
        sessionManagement = new Session(LoginActivity.this);
        String userID = sessionManagement.getSession1();
        String exname = db.loadData(userID);
        intent.putExtra("name", exname);
        String class_a = db.setClass(userID);
        intent.putExtra("class", class_a);
        String khoa = db.setKhoa(userID);
        intent.putExtra("khoa", khoa);
        String k = db.setK(userID);
        intent.putExtra("K", k);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    private void moveToLogin() {
            String s1 = id.getText().toString().trim();
            String s2 = pw.getText().toString();
            Boolean check = db.check_idpw(s1, s2);
            if (br.isNetworkAvailable(this) == true){
            if (check == true ) {
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                intent.putExtra("name_id", sessionManagement.getSession1());
                String exname = db.loadData(s1);
                intent.putExtra("name", exname);
                String class_a = db.setClass(s1);
                intent.putExtra("class", class_a);
                String khoa = db.setKhoa(s1);
                intent.putExtra("khoa", khoa);
                String k = db.setK(s1);
                intent.putExtra("K", k);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            } else {
                Toast.makeText(getApplicationContext(), "Thất bại", Toast.LENGTH_SHORT).show();
                Session sessionManagement = new Session(LoginActivity.this);
                sessionManagement.removeSession1();
            }
        } else {
        Toast.makeText(getApplicationContext(), "Lỗi đường truyền, vui lòng kiểm tra lại !!!", Toast.LENGTH_SHORT).show();
        Session sessionManagement = new Session(LoginActivity.this);
        sessionManagement.removeSession1();
    }}
    //}

}





