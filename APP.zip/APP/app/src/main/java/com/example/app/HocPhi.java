package com.example.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class HocPhi extends AppCompatActivity {
    private MainActivity mainActivity;
    DBHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hoc_phi);
        db = new DBHelper(this);
        BarChart barChart = findViewById(R.id.barchart);
        ArrayList<BarEntry> visitor = new ArrayList<>();
        String userID = getIntent().getStringExtra("name_id");
        visitor = db.setnam(userID);


        BarDataSet barDataSet = new BarDataSet(visitor,null);
        barDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        barDataSet.setValueTextColor(Color.BLACK);
        barDataSet.setValueTextSize(16f);
        BarData barData = new BarData(barDataSet);
        barChart.setFitBars(true);
        barChart.setData(barData);
        barChart.animateY(2000);
    }
    public void hocphi_back(View view) {
        Intent intent = new Intent(HocPhi.this, LoginActivity.class);
        startActivity(intent);
    }
}