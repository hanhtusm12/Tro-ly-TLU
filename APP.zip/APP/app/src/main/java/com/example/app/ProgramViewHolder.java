package com.example.app;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class ProgramViewHolder {
    TextView tensach;
    TextView ngaymuon;
    TextView ngayhentra;
    ProgramViewHolder (View v){
        tensach = v.findViewById(R.id.tensachchuatra);
        ngaymuon = v.findViewById(R.id.ngaymuon);
        ngayhentra = v.findViewById(R.id.ngayhentra);
    }
}
