package com.example.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Information extends AppCompatActivity implements View.OnClickListener {
    private Button infor_back;
    private ImageButton dial_call;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);

        dial_call = findViewById(R.id.dial_call);
        dial_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel: 0773309529"));
                startActivity(intent);
            }
        });
    }


    @Override
    public void onClick(View v) {
    }

    public void infor_back(View view) {
        Intent intent = new Intent(Information.this, LoginActivity.class);
        startActivity(intent);
    }


}