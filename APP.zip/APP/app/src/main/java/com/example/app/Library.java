package com.example.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Library extends AppCompatActivity {
    private String main_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library);
        BottomNavigationView btnNav = findViewById(R.id.nav_library);
        btnNav.setOnNavigationItemSelectedListener(navListener);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment2, new sachchuatra()).commit();
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment selectedFragment = null;
            switch (item.getItemId()){
                case R.id.sachchuatra:
                    selectedFragment = new sachchuatra();
                    break;
                case R.id.sachdatra:
                    selectedFragment = new sachdatra();
                    break;
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment2, selectedFragment).commit();
            return true;

        }
    };

    public String setID(){
        main_id = getIntent().getStringExtra("name_id");
        return main_id;
    }
    public void lib_back(View view) {
        Intent intent = new Intent(Library.this, LoginActivity.class);
        startActivity(intent);
    }
}