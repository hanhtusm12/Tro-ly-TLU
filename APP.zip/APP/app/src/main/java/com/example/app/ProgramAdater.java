package com.example.app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class ProgramAdater extends ArrayAdapter<String> {
    Context context;
    ArrayList<String> tensach;
    ArrayList<String> ngaymuon;
    ArrayList<String> ngayhentra;
    public ProgramAdater(Context context, ArrayList<String> tensach, ArrayList<String> ngaymuon, ArrayList<String> ngayhentra) {
        super(context, R.layout.item_library, R.id.tensachchuatra, tensach);
        this.context = context;
        this.tensach = tensach;
        this.ngaymuon = ngaymuon;
        this.ngayhentra = ngayhentra;
    }

    @Override
    public View getView(int position,View convertView,ViewGroup parent) {
        View singleItem = convertView;
        ProgramViewHolder holder = null;
        if (singleItem == null){
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            singleItem = layoutInflater.inflate(R.layout.item_library, parent, false);
            holder = new ProgramViewHolder(singleItem);
            singleItem.setTag(holder);
        }
        else {
            holder = (ProgramViewHolder) singleItem.getTag();
        }
        holder.tensach.setText(tensach.get(position));
        holder.ngaymuon.setText(ngaymuon.get(position));
        holder.ngayhentra.setText(ngayhentra.get(position));
        return singleItem;
    }
}
