package com.example.app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import java.util.ArrayList;

public class AnhXaDiem extends ArrayAdapter<String> {
    Context context;
    ArrayList<String> tenmon;
    ArrayList<String> dqt;
    ArrayList<String> thi;
    ArrayList<String> diemchu;

    public AnhXaDiem(Context context, ArrayList<String> tenmon, ArrayList<String> dqt, ArrayList<String> thi, ArrayList<String> diemchu) {
        super(context, R.layout.single_item, R.id.textview1, tenmon);
        this.context = context;
        this.tenmon = tenmon;
        this.dqt = dqt;
        this.thi = thi;
        this.diemchu = diemchu;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View singleItem = convertView;
        HolderDiem holder = null;
        if (singleItem == null){
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            singleItem = layoutInflater.inflate(R.layout.single_item, parent, false);
            holder = new HolderDiem(singleItem);
            singleItem.setTag(holder);
        }
        else {
            holder = (HolderDiem) singleItem.getTag();
        }
        holder.tenmon.setText(tenmon.get(position));
        holder.dqt.setText(dqt.get(position));
        holder.thi.setText(thi.get(position));
        holder.diemchu.setText(diemchu.get(position));
        return singleItem;
    }
}

