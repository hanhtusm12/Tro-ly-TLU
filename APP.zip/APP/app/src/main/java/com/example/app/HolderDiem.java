package com.example.app;

import android.view.View;
import android.widget.TextView;


public class HolderDiem {
    TextView tenmon;
    TextView dqt;
    TextView thi;
    TextView diemchu;
    HolderDiem (View v){
        tenmon = v.findViewById(R.id.textview1);
        dqt = v.findViewById(R.id.dqt);
        thi = v.findViewById(R.id.textview2);
        diemchu = v.findViewById(R.id.diemchu);
    }
}
