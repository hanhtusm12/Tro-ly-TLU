package com.example.app;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;


public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context) {
        super(context,"Login.db",null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists sinhvien");
    }

    public boolean insert(String id, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("id", id);
        contentValues.put("password", password);
        long ins = db.insert("sinhvien" ,null, contentValues);
        return ins != -1;
    }

    public Boolean check_id(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from sinhvien where MSV=?", new String[]{id});
        if (cursor.getCount()>0) return false;
        else return true;
    }
    //Check ten dang nhap va mat khau
    public Boolean check_idpw(String id, String pw){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from sinhvien where MSV=? and NgaySinh=?", new String[]{id, pw});
        String s=String.valueOf(cursor.getCount());
        return cursor.getCount() > 0;
    }
    //Lay ra ten sinh vien
    public String loadData(String id){
        String name="hello world123";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from sinhvien where MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            name = cursor.getString(1);
        }
        return name;
    }
    //Lay ra lop
    public String setClass(String id){
        String name="hello world123";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select tenlop from sinhvien,lop where sinhvien.malop = lop.malop and MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            name = cursor.getString(0);
        }
        return name;
    }
    //Lay ra khoa
    public String setKhoa(String id){
        String name="hello world123";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select tenkhoa from sinhvien,khoa where sinhvien.makhoa = khoa.makhoa and MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            name = cursor.getString(0);
        }
        return name;
    }

    //Lay ra K
    public String setK(String id){
        String name="hello world123";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select K from sinhvien where MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            name = cursor.getString(0);
        }
        return name;
    }

    //Lay ra tien hoc phi nam 2014
    public String setNam(String id){
        String name="hello world123";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select sum(TinChi)*305000 from SinhVien, DKH, MonHoc where sinhvien.MSV = dkh.MSV and dkh.MaMon = MonHoc.MaMon and dkh.MSV =? and NamHoc ='2014'", new String[]{id});
        while (cursor.moveToNext()) {
            name = cursor.getString(0);
        }
        return name;
    }
}
