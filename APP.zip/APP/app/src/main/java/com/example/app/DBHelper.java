package com.example.app;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import com.github.mikephil.charting.data.BarEntry;

import java.util.ArrayList;
import java.util.List;


public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context) {
        super(context,"Login.db",null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists sinhvien");
    }


    //Kiểm tra xem có id trong csdl hay không nếu có trả về false, ngược lại trả về true
    public Boolean check_id(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from sinhvien where MSV=?", new String[]{id});
        if (cursor.getCount()>0) return false;
        else return true;
    }

    //Check ten dang nhap va mat khau
    public Boolean check_idpw(String id, String pw){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from sinhvien where MSV=? and NgaySinh=?", new String[]{id, pw});
        String s=String.valueOf(cursor.getCount());
        return cursor.getCount() > 0;
    }

    //Lay ra ten sinh vien
    public String loadData(String id){
        String name="hello world123";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from sinhvien where MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            name = cursor.getString(1);
        }
        return name;
    }

    //Lay ra lop
    public String setClass(String id){
        String name="hello world123";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select tenlop from sinhvien,lop where sinhvien.malop = lop.malop and MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            name = cursor.getString(0);
        }
        return name;
    }

    //Lay ra khoa
    public String setKhoa(String id){
        String name="hello world123";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select tenkhoa from sinhvien,khoa where sinhvien.makhoa = khoa.makhoa and MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            name = cursor.getString(0);
        }
        return name;
    }

    //Lay ra K
    public String setK(String id){
        String name="hello world123";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select K from sinhvien where MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            name = cursor.getString(0);
        }
        return name;
    }

    //Lay ra ten mon hoc
    public  ArrayList<String> setMonhoc(String id){
        ArrayList<String> name = new ArrayList<>() ;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select Tenmon from MonHoc, Tongketdiem where MonHoc.MaMon = Tongketdiem.MaMon and Tongketdiem.MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            String ten = cursor.getString(0);
            name.add(ten);
        }
        return name;
    }

    //Lay ra dqt
    public  ArrayList<String> setDQT(String id){
        ArrayList<String> name = new ArrayList<>() ;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select DQT from MonHoc, Tongketdiem where MonHoc.MaMon = Tongketdiem.MaMon and Tongketdiem.MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            String ten = cursor.getString(0);
            name.add(ten);
        }
        return name;
    }

    //Lay ra ten diem thi
    public  ArrayList<String> setDT(String id){
        ArrayList<String> name = new ArrayList<>() ;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select Diemthi from MonHoc, Tongketdiem where MonHoc.MaMon = Tongketdiem.MaMon and Tongketdiem.MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            String ten = cursor.getString(0);
            name.add(ten);
        }
        return name;
    }

    //Lay ra ten diem chu
    public  ArrayList<String> setdiemchu(String id){
        ArrayList<String> name = new ArrayList<>() ;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select Chu from MonHoc, Tongketdiem where MonHoc.MaMon = Tongketdiem.MaMon and Tongketdiem.MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            String ten = cursor.getString(0);
            name.add(ten);
        }
        return name;
    }

    public ArrayList<BarEntry> setnam(String id){
        ArrayList<BarEntry> visitors = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from SinhVien, HocPhi where sinhvien.MSV = hocphi.MSV and hocphi.MSV =?", new String[]{id});
        while (cursor.moveToNext()) {
            int nam = cursor.getInt(9);
            int hocphi = cursor.getInt(8);
            visitors.add(new BarEntry(nam, hocphi));
        }
        return visitors;
    }

    //Lay ra ten mon sach da tra
    public  ArrayList<String> setSachchuatra(String id){
        ArrayList<String> name = new ArrayList<>() ;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select Tensach from sinhvien,Sach, MuonSach, CTMuonSach where Sach.Masach = muonsach.masach and sinhvien.msv = muonsach.msv and muonsach.mamuon = ctmuonsach.mamuon and tinhtrang = 0  and  muonsach.MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            String ten = cursor.getString(0);
            name.add(ten);
        }
        return name;
    }

    //Lay ra ngay muon
    public  ArrayList<String> setngaymuon(String id){
        ArrayList<String> name = new ArrayList<>() ;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select ngaymuon from sinhvien,Sach, MuonSach, CTMuonSach where Sach.Masach = muonsach.masach and sinhvien.msv = muonsach.msv and muonsach.mamuon = ctmuonsach.mamuon and tinhtrang = 0  and  muonsach.MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            String ten = cursor.getString(0);
            name.add(ten);
        }
        return name;
    }

    //Lay ra ngay hen tra
    public  ArrayList<String> setngaytra(String id){
        ArrayList<String> name = new ArrayList<>() ;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select ngayhentra from sinhvien,Sach, MuonSach, CTMuonSach where Sach.Masach = muonsach.masach and sinhvien.msv = muonsach.msv and muonsach.mamuon = ctmuonsach.mamuon and tinhtrang = 0  and  muonsach.MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            String ten = cursor.getString(0);
            name.add(ten);
        }
        return name;
    }

    //Lay ra ten mon sach chua tra
    public  ArrayList<String> setSachdatra(String id){
        ArrayList<String> name = new ArrayList<>() ;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select Tensach from sinhvien,Sach, MuonSach, CTMuonSach where Sach.Masach = muonsach.masach and sinhvien.msv = muonsach.msv and muonsach.mamuon = ctmuonsach.mamuon and tinhtrang = 1  and  muonsach.MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            String ten = cursor.getString(0);
            name.add(ten);
        }
        return name;
    }

    //Lay ra ngay muon
    public  ArrayList<String> setngaymuon2(String id){
        ArrayList<String> name = new ArrayList<>() ;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select ngaymuon from sinhvien,Sach, MuonSach, CTMuonSach where Sach.Masach = muonsach.masach and sinhvien.msv = muonsach.msv and muonsach.mamuon = ctmuonsach.mamuon and tinhtrang = 1  and  muonsach.MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            String ten = cursor.getString(0);
            name.add(ten);
        }
        return name;
    }

    //Lay ra ngay hen tra
    public  ArrayList<String> setngaytra2(String id){
        ArrayList<String> name = new ArrayList<>() ;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select ngayhentra from sinhvien,Sach, MuonSach, CTMuonSach where Sach.Masach = muonsach.masach and sinhvien.msv = muonsach.msv and muonsach.mamuon = ctmuonsach.mamuon and tinhtrang = 1  and  muonsach.MSV=?", new String[]{id});
        while (cursor.moveToNext()) {
            String ten = cursor.getString(0);
            name.add(ten);
        }
        return name;
    }
}
