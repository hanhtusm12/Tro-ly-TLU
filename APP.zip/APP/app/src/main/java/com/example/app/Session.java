package com.example.app;

import android.content.Context;
import android.content.SharedPreferences;

public class Session {
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    String SHARED_PREF_NAME = "session";
    String SESSION_KEY = "session_user";
    String SESSION_PASS = "session_pass";

    public Session(Context context){
        sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public void saveSession1(User user){
        String id =  user.getId();
        String pass =  user.getName();
        editor.putString(SESSION_KEY,id).commit();
        editor.putString(SESSION_PASS,pass).commit();
    }

    public String getSession1(){

        return sharedPreferences.getString(SESSION_KEY, "1");
    }
    public String getSession(){

        return sharedPreferences.getString(SESSION_PASS, "1");
    }
    public void removeSession1(){
        editor.putString(SESSION_KEY,"1").commit();
        editor.putString(SESSION_PASS,"1").commit();

    }
}
